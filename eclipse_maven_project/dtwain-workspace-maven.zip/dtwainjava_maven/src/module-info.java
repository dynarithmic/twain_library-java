/**
 * 
 */
/**
 * @author Paul
 *
 */
module dtwainjava_maven {
	requires org.apache.commons.lang3;
	requires org.apache.commons.imaging;
	requires java.desktop;
	requires javatuples;
	requires java.logging;
}