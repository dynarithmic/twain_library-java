package com.dynarithmic.twain.exceptions;

public class DTwainJavaAPIException extends Exception
{
    /**
     *
     */
    private static final long serialVersionUID = -1977774142175948521L;
    public DTwainJavaAPIException()
    {
        super("Unrecoverable error in DTWAINJavaAPI.DLL");
    }

    public DTwainJavaAPIException(String s)
    {
        super(s);
    }

}
