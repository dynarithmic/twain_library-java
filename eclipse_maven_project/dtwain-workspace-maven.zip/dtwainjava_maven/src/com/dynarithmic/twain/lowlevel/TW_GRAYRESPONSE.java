package com.dynarithmic.twain.lowlevel;

public class TW_GRAYRESPONSE extends TW_RESPONSETYPE
{}
