package com.dynarithmic.twain.lowlevel;

public class TW_NULL extends TwainLowLevel
{
    public TW_NULL() {}
}
