package com.dynarithmic.twain.lowlevel;

public class TW_RGBRESPONSE extends TW_RESPONSETYPE
{}
