package com.dynarithmic.twain.lowlevel;

public class TwainLowLevel
{
    public TwainLowLevel() {}
    public Object getTwainObject() { return this; }
}
