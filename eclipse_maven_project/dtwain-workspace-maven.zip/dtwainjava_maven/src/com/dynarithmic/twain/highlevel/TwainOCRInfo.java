package com.dynarithmic.twain.highlevel;

public class TwainOCRInfo extends TwainAppInfo
{
    public TwainOCRInfo()
    { super();  }

    public TwainOCRInfo(String ver, String manu, String prodFamily, String prodName)
    { super(ver, manu, prodFamily, prodName); }
}
