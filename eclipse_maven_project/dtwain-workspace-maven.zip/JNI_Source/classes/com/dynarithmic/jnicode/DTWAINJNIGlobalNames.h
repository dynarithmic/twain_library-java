#ifndef DTWAINJNIGLOBALNAMES_H
#define DTWAINJNIGLOBALNAMES_H
#include <string>
#endif
